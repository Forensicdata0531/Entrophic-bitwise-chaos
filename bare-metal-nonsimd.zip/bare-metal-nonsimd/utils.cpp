#include "utils.hpp"
#include <iostream>
#include <iomanip>

// Load entire file content into a string
std::string loadBlockTemplate(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open file: " + filepath);
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

// Convert byte vector to hex string
std::string bytesToHex(const std::vector<uint8_t>& bytes) {
    static const char hexmap[] = "0123456789abcdef";
    std::string hex;
    hex.reserve(bytes.size() * 2);
    for (uint8_t b : bytes) {
        hex += hexmap[(b >> 4) & 0xF];
        hex += hexmap[b & 0xF];
    }
    return hex;
}

// Convert hex string to bytes
std::vector<uint8_t> hexToBytes(const std::string& hex) {
    std::vector<uint8_t> bytes;
    bytes.reserve(hex.size() / 2);
    for (size_t i = 0; i < hex.size(); i += 2) {
        std::string byteString = hex.substr(i, 2);
        uint8_t byte = static_cast<uint8_t>(strtol(byteString.c_str(), nullptr, 16));
        bytes.push_back(byte);
    }
    return bytes;
}

// Remove or comment out serializeHeader80 to avoid multiple definitions
/*
std::vector<uint8_t> serializeHeader80(const BlockHeader& header) {
    return header.toBytes();
}
*/

// Calculate midstate of 64-byte header prefix using OpenSSL EVP SHA256
Midstate calculateMidstate(const std::vector<uint8_t>& headerPrefix) {
    if (headerPrefix.size() != 64) {
        throw std::runtime_error("Header prefix must be exactly 64 bytes");
    }

    Midstate midstate;

    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    if (!ctx) throw std::runtime_error("Failed to create EVP_MD_CTX");

    if (EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr) != 1)
        throw std::runtime_error("EVP_DigestInit_ex failed");

    if (EVP_DigestUpdate(ctx, headerPrefix.data(), headerPrefix.size()) != 1)
        throw std::runtime_error("EVP_DigestUpdate failed");

    unsigned int outLen = 32;
    uint8_t digest[32];
    if (EVP_DigestFinal_ex(ctx, digest, &outLen) != 1)
        throw std::runtime_error("EVP_DigestFinal_ex failed");

    EVP_MD_CTX_free(ctx);

    // Copy digest to midstate as 8 32-bit words in big endian
    for (int i = 0; i < 8; ++i) {
        midstate.h[i] =
            (digest[i * 4 + 0] << 24) |
            (digest[i * 4 + 1] << 16) |
            (digest[i * 4 + 2] << 8) |
            (digest[i * 4 + 3]);
    }

    return midstate;
}
