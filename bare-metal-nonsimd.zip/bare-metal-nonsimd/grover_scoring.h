#pragma once
#include "midstate_utils.h"

float score_midstate(const Midstate& m);

