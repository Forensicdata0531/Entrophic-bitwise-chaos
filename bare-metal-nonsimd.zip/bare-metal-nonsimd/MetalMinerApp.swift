//
//  MetalMinerApp.swift
//  MetalMiner
//
//  Created by Jw2Fresh420 on 5/24/25.
//

import SwiftUI

@main
struct MetalMinerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
