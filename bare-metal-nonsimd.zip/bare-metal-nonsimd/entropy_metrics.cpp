#include "entropy_metrics.hpp"
#include "utils.hpp"
#include <cmath>

// Convert midstate words to bytes
std::vector<uint8_t> calculateSHA256Midstate(const std::vector<uint8_t>& headerPrefix) {
    Midstate midstate = calculateMidstate(headerPrefix);
    std::vector<uint8_t> midstateBytes(32);
    for (int i = 0; i < 8; ++i) {
        uint32_t word = midstate.h[i];
        midstateBytes[i * 4 + 0] = (word >> 24) & 0xff;
        midstateBytes[i * 4 + 1] = (word >> 16) & 0xff;
        midstateBytes[i * 4 + 2] = (word >> 8) & 0xff;
        midstateBytes[i * 4 + 3] = (word >> 0) & 0xff;
    }
    return midstateBytes;
}

// Calculate Shannon entropy of byte array normalized between 0 and 8 bits per byte
double entropyMetric(const std::vector<uint8_t>& data) {
    if (data.empty()) return 0.0;
    int counts[256] = {0};
    for (auto b : data) counts[b]++;
    double entropy = 0.0;
    double len = (double)data.size();

    for (int i = 0; i < 256; i++) {
        if (counts[i] == 0) continue;
        double p = counts[i] / len;
        entropy -= p * log2(p);
    }
    return entropy;
}

// Dummy example: entropy score from nonce value
double blockEntropyScore(uint64_t nonce) {
    std::vector<uint8_t> bytes(8);
    for (int i = 0; i < 8; i++) {
        bytes[i] = (nonce >> (8 * i)) & 0xff;
    }
    return entropyMetric(bytes);
}
