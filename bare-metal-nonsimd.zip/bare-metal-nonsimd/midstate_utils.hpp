#pragma once
#include "block.hpp"
#include "utils.hpp"
#include <vector>
#include <array>
#include <string>
#include <stdexcept>

// Computes midstate and tail bytes from block header
void computeMidstate(const BlockHeader& header, std::array<uint32_t, 8>& midstate, std::vector<uint8_t>& tail);
