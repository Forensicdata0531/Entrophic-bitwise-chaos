#pragma once
#include <vector>
#include <array>
#include <cstdint>
#include "block.hpp"

// Double SHA256 using OpenSSL EVP interface
std::vector<uint8_t> doubleSHA256(const uint8_t* data, size_t len);

// Serialize BlockHeader to 80-byte Bitcoin header (little-endian)
std::vector<uint8_t> serializeHeader80(const BlockHeader& header);

// Calculate SHA256 midstate from first 64 bytes of header prefix
// Returns 8 uint32_t words (big endian) representing the SHA256 midstate
std::array<uint32_t, 8> calculateMidstateArray(const std::vector<uint8_t>& headerPrefix);
