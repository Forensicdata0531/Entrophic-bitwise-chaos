#include "block_utils.hpp"
#include "sha256_wrapper.hpp"
#include <cstring>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <atomic>

// Global mining stats for CPU fallback
struct MiningStats {
    std::atomic<uint64_t> hashes{0};
    std::atomic<bool>* quit = nullptr;
};

static MiningStats stats;

void printProgress(uint64_t hashesDone) {
    std::cerr << "[DEBUG] Total hashes computed so far: " << hashesDone << std::endl;
}

// Removed duplicate of serializeHeader80

std::vector<uint8_t> calculateTargetFromBits(uint32_t bits) {
    uint32_t exponent = bits >> 24;
    uint32_t mantissa = bits & 0xFFFFFF;
    std::vector<uint8_t> target(32, 0x00);

    int shift = exponent - 3;
    if (shift >= 0 && shift + 3 <= 32) {
        target[shift] = (mantissa >> 16) & 0xFF;
        target[shift + 1] = (mantissa >> 8) & 0xFF;
        target[shift + 2] = mantissa & 0xFF;
    }

    return target;
}

bool cpuMineBlock(const BlockHeader& header, const std::vector<uint8_t>& target, uint32_t nonceStart, uint32_t nonceEnd, uint32_t& validNonce, std::vector<uint8_t>& validHash) {
    std::cerr << "[DEBUG] CPU mining start nonce range: " << nonceStart << " to " << nonceEnd << std::endl;

    BlockHeader blockHeader = header;
    for (uint32_t nonce = nonceStart; nonce < nonceEnd; ++nonce) {
        blockHeader.nonce = nonce;
        auto headerBytes = serializeHeader80(blockHeader);
        auto hash = doubleSHA256(headerBytes.data(), headerBytes.size());

        stats.hashes++;

        if (std::lexicographical_compare(hash.begin(), hash.end(), target.begin(), target.end())) {
            validNonce = nonce;
            validHash.assign(hash.begin(), hash.end());
            std::cerr << "[DEBUG] Valid nonce found: " << nonce << std::endl;
            return true;
        }

        if (stats.hashes % 1000000 == 0) {
            printProgress(stats.hashes);
        }
    }

    std::cerr << "[DEBUG] CPU mining completed nonce range without success.\n";
    return false;
}
