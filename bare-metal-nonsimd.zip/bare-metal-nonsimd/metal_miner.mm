#import <Metal/Metal.h>
#import <Foundation/Foundation.h>
#include "block.hpp"
#include "shared.hpp"
#include <iostream>
#include <vector>
#include <cstring>
#include <array>
#include <stdexcept>
#include <mach-o/dyld.h> // For _NSGetExecutablePath

// The Metal mining function
bool metalMineBlock(
    const BlockHeader& header,
    const std::vector<uint8_t>& target,
    uint32_t /*initialNonceBase*/,  // Unused parameter
    uint32_t& validNonce,
    std::vector<uint8_t>& validHash,
    uint64_t maxThreads)
{
    id<MTLDevice> device = MTLCreateSystemDefaultDevice();
    if (!device) {
        std::cerr << "[ERROR] Metal device not found.\n";
        return false;
    }

    NSError *error = nil;

    // Dynamically find the metallib relative to executable
    char execPath[PATH_MAX];
    uint32_t size = sizeof(execPath);
    if (_NSGetExecutablePath(execPath, &size) != 0) {
        std::cerr << "[ERROR] Failed to get executable path.\n";
        return false;
    }
    NSString *execNSString = [NSString stringWithUTF8String:execPath];
    NSString *execDir = [execNSString stringByDeletingLastPathComponent];
    NSString *libPath = [execDir stringByAppendingPathComponent:@"mineKernel.metallib"];
    NSURL *libURL = [NSURL fileURLWithPath:libPath];

    id<MTLLibrary> library = [device newLibraryWithURL:libURL error:&error];
    if (!library) {
        std::cerr << "[ERROR] Failed to load Metal library: " << error.localizedDescription.UTF8String << "\n";
        return false;
    }

    id<MTLFunction> function = [library newFunctionWithName:@"mineKernel"];
    if (!function) {
        std::cerr << "[ERROR] Failed to find kernel function.\n";
        return false;
    }

    id<MTLComputePipelineState> pipelineState = [device newComputePipelineStateWithFunction:function error:&error];
    if (error) {
        std::cerr << "[ERROR] Pipeline creation failed: " << error.localizedDescription.UTF8String << "\n";
        return false;
    }

    id<MTLCommandQueue> commandQueue = [device newCommandQueue];
    if (!commandQueue) {
        std::cerr << "[ERROR] Failed to create command queue.\n";
        return false;
    }

    BlockHeader headerNoNonce = header;
    headerNoNonce.nonce = 0;

    auto headerBytes = serializeHeader80(headerNoNonce);
    std::vector<uint8_t> headerPrefix(headerBytes.begin(), headerBytes.begin() + 64);

    std::array<uint32_t,8> midstate;
    try {
        midstate = calculateMidstateArray(headerPrefix);
    } catch (const std::exception& e) {
        std::cerr << "[ERROR] Midstate calculation failed: " << e.what() << "\n";
        return false;
    }

    id<MTLBuffer> midstateBuffer = [device newBufferWithBytes:midstate.data()
                                                      length:sizeof(midstate)
                                                     options:MTLResourceStorageModeShared];

    id<MTLBuffer> targetBuffer = [device newBufferWithBytes:target.data()
                                                    length:target.size()
                                                   options:MTLResourceStorageModeShared];

    std::vector<uint8_t> tailBlock(headerBytes.begin() + 64, headerBytes.end());
    id<MTLBuffer> tailBuffer = [device newBufferWithBytes:tailBlock.data()
                                                  length:tailBlock.size()
                                                 options:MTLResourceStorageModeShared];

    // Buffers for output (atomic types)
    uint32_t outputNonceValue = 0;
    bool foundFlagValue = false;

    id<MTLBuffer> outputNonceBuffer = [device newBufferWithBytes:&outputNonceValue
                                                          length:sizeof(outputNonceValue)
                                                         options:MTLResourceStorageModeShared];

    id<MTLBuffer> foundFlagBuffer = [device newBufferWithBytes:&foundFlagValue
                                                        length:sizeof(foundFlagValue)
                                                       options:MTLResourceStorageModeShared];

    id<MTLCommandBuffer> commandBuffer = [commandQueue commandBuffer];
    id<MTLComputeCommandEncoder> encoder = [commandBuffer computeCommandEncoder];

    [encoder setComputePipelineState:pipelineState];
    [encoder setBuffer:midstateBuffer offset:0 atIndex:0];
    [encoder setBuffer:tailBuffer offset:0 atIndex:1];
    [encoder setBuffer:targetBuffer offset:0 atIndex:2];
    [encoder setBuffer:outputNonceBuffer offset:0 atIndex:3];
    [encoder setBuffer:foundFlagBuffer offset:0 atIndex:4];

    MTLSize threadsPerThreadgroup = MTLSizeMake(32, 1, 1);
    uint32_t totalThreads = (uint32_t)maxThreads;
    uint32_t threadgroups = (totalThreads + threadsPerThreadgroup.width - 1) / threadsPerThreadgroup.width;
    MTLSize threadgroupsPerGrid = MTLSizeMake(threadgroups, 1, 1);

    [encoder dispatchThreadgroups:threadgroupsPerGrid threadsPerThreadgroup:threadsPerThreadgroup];
    [encoder endEncoding];

    [commandBuffer commit];
    [commandBuffer waitUntilCompleted];

    // Read back results from buffer memory
    bool found = *reinterpret_cast<bool*>(foundFlagBuffer.contents);
    if (found) {
        validNonce = *reinterpret_cast<uint32_t*>(outputNonceBuffer.contents);
        BlockHeader validHeader = headerNoNonce;
        validHeader.nonce = validNonce;
        auto finalHeaderBytes = serializeHeader80(validHeader);
        validHash = doubleSHA256(finalHeaderBytes.data(), finalHeaderBytes.size());
        return true;
    }

    return false;
}
