#ifndef UTILS_HPP
#define UTILS_HPP

#include <vector>
#include <array>
#include <cstdint>
#include <string>
#include <stdexcept>
#include <fstream>
#include <sstream>
#include "block.hpp"
#include <openssl/evp.h>
#include "nlohmann/json.hpp"

using json = nlohmann::json;

struct Midstate {
    std::array<uint32_t, 8> h;
};

Midstate calculateMidstate(const std::vector<uint8_t>& headerPrefix);

std::string bytesToHex(const std::vector<uint8_t>& bytes);

std::vector<uint8_t> hexToBytes(const std::string& hex);

// Remove or comment out the following line to avoid conflict:
// std::vector<uint8_t> serializeHeader80(const BlockHeader& header);

std::string loadBlockTemplate(const std::string& filepath);

#endif // UTILS_HPP
