#ifndef BLOCK_UTILS_HPP
#define BLOCK_UTILS_HPP

#include <vector>
#include <cstdint>
#include "blockheader.hpp"

// Serialize 80-byte Bitcoin block header
std::vector<uint8_t> serializeHeader80(const BlockHeader& header);

// Convert compact difficulty bits to 256-bit target
std::vector<uint8_t> calculateTargetFromBits(uint32_t bits);

// CPU-based mining fallback
bool cpuMineBlock(
    const BlockHeader& header,
    const std::vector<uint8_t>& target,
    uint32_t nonceStart,
    uint32_t nonceEnd,
    uint32_t& validNonce,
    std::vector<uint8_t>& validHash
);

#endif // BLOCK_UTILS_HPP
