#include "block.hpp"
#include "shared.hpp"
#include <vector>
#include <array>
#include <cstdint>
#include <stdexcept>
#include <cstring>
#include <openssl/evp.h>

// Minimal SHA256 implementation exposing midstate (adapted from public domain code)
struct SHA256_CTX {
    uint32_t state[8];
    uint64_t bitcount;
    uint8_t buffer[64];
};

void SHA256_Init(SHA256_CTX* ctx);
void SHA256_Update(SHA256_CTX* ctx, const uint8_t* data, size_t len);
void SHA256_Transform(SHA256_CTX* ctx, const uint8_t* data);

// Helper macros and constants (SHA256)
#define ROTRIGHT(word,bits) (((word) >> (bits)) | ((word) << (32-(bits))))
#define CH(x,y,z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x,y,z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x) (ROTRIGHT(x,2) ^ ROTRIGHT(x,13) ^ ROTRIGHT(x,22))
#define EP1(x) (ROTRIGHT(x,6) ^ ROTRIGHT(x,11) ^ ROTRIGHT(x,25))
#define SIG0(x) (ROTRIGHT(x,7) ^ ROTRIGHT(x,18) ^ ((x) >> 3))
#define SIG1(x) (ROTRIGHT(x,17) ^ ROTRIGHT(x,19) ^ ((x) >> 10))

static const uint32_t k[64] = {
    0x428a2f98ul,0x71374491ul,0xb5c0fbcful,0xe9b5dba5ul,
    0x3956c25bul,0x59f111f1ul,0x923f82a4ul,0xab1c5ed5ul,
    0xd807aa98ul,0x12835b01ul,0x243185beul,0x550c7dc3ul,
    0x72be5d74ul,0x80deb1feul,0x9bdc06a7ul,0xc19bf174ul,
    0xe49b69c1ul,0xefbe4786ul,0x0fc19dc6ul,0x240ca1ccul,
    0x2de92c6ful,0x4a7484aaul,0x5cb0a9dcul,0x76f988daul,
    0x983e5152ul,0xa831c66dul,0xb00327c8ul,0xbf597fc7ul,
    0xc6e00bf3ul,0xd5a79147ul,0x06ca6351ul,0x14292967ul,
    0x27b70a85ul,0x2e1b2138ul,0x4d2c6dfcul,0x53380d13ul,
    0x650a7354ul,0x766a0abbul,0x81c2c92eul,0x92722c85ul,
    0xa2bfe8a1ul,0xa81a664bul,0xc24b8b70ul,0xc76c51a3ul,
    0xd192e819ul,0xd6990624ul,0xf40e3585ul,0x106aa070ul,
    0x19a4c116ul,0x1e376c08ul,0x2748774cul,0x34b0bcb5ul,
    0x391c0cb3ul,0x4ed8aa4aul,0x5b9cca4ful,0x682e6ff3ul,
    0x748f82eeul,0x78a5636ful,0x84c87814ul,0x8cc70208ul,
    0x90befffaul,0xa4506cebul,0xbef9a3f7ul,0xc67178f2ul
};

void SHA256_Transform(SHA256_CTX* ctx, const uint8_t* data) {
    uint32_t a,b,c,d,e,f,g,h,i,j,t1,t2,m[64];

    for (i=0,j=0; i < 16; ++i,j += 4)
        m[i] = (data[j] << 24) | (data[j+1] << 16) | (data[j+2] << 8) | (data[j+3]);

    for ( ; i < 64; ++i)
        m[i] = SIG1(m[i-2]) + m[i-7] + SIG0(m[i-15]) + m[i-16];

    a = ctx->state[0];
    b = ctx->state[1];
    c = ctx->state[2];
    d = ctx->state[3];
    e = ctx->state[4];
    f = ctx->state[5];
    g = ctx->state[6];
    h = ctx->state[7];

    for (i=0; i < 64; ++i) {
        t1 = h + EP1(e) + CH(e,f,g) + k[i] + m[i];
        t2 = EP0(a) + MAJ(a,b,c);
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }

    ctx->state[0] += a;
    ctx->state[1] += b;
    ctx->state[2] += c;
    ctx->state[3] += d;
    ctx->state[4] += e;
    ctx->state[5] += f;
    ctx->state[6] += g;
    ctx->state[7] += h;
}

void SHA256_Init(SHA256_CTX* ctx) {
    ctx->bitcount = 0;
    ctx->state[0] = 0x6a09e667ul;
    ctx->state[1] = 0xbb67ae85ul;
    ctx->state[2] = 0x3c6ef372ul;
    ctx->state[3] = 0xa54ff53aul;
    ctx->state[4] = 0x510e527ful;
    ctx->state[5] = 0x9b05688cul;
    ctx->state[6] = 0x1f83d9abul;
    ctx->state[7] = 0x5be0cd19ul;
}

void SHA256_Update(SHA256_CTX* ctx, const uint8_t* data, size_t len) {
    size_t i = 0;
    size_t idx = (ctx->bitcount >> 3) % 64;
    ctx->bitcount += ((uint64_t)len) << 3;

    if (idx) {
        size_t fill = 64 - idx;
        if (len < fill) fill = len;
        memcpy(&ctx->buffer[idx], &data[0], fill);
        idx += fill;
        if (idx < 64) return;
        SHA256_Transform(ctx, ctx->buffer);
        i += fill;
    }

    for ( ; i + 63 < len; i += 64)
        SHA256_Transform(ctx, &data[i]);

    if (len - i > 0)
        memcpy(ctx->buffer, &data[i], len - i);
}

void SHA256_Final(uint8_t* digest, SHA256_CTX* ctx) {
    uint8_t pad[64] = {0x80};
    uint8_t len_bytes[8];
    size_t idx = (ctx->bitcount >> 3) % 64;
    size_t pad_len = (idx < 56) ? (56 - idx) : (120 - idx);

    for (int i = 0; i < 8; ++i)
        len_bytes[7 - i] = (ctx->bitcount >> (8 * i)) & 0xFF;

    SHA256_Update(ctx, pad, pad_len);
    SHA256_Update(ctx, len_bytes, 8);

    for (int i = 0; i < 8; ++i) {
        digest[i*4]   = (ctx->state[i] >> 24) & 0xff;
        digest[i*4+1] = (ctx->state[i] >> 16) & 0xff;
        digest[i*4+2] = (ctx->state[i] >> 8) & 0xff;
        digest[i*4+3] = (ctx->state[i]) & 0xff;
    }
}

std::vector<uint8_t> serializeHeader80(const BlockHeader& header) {
    std::vector<uint8_t> buffer(80);

    // Version (4 bytes, little endian)
    buffer[0] = header.version & 0xFF;
    buffer[1] = (header.version >> 8) & 0xFF;
    buffer[2] = (header.version >> 16) & 0xFF;
    buffer[3] = (header.version >> 24) & 0xFF;

    // Prev block hash (32 bytes, little endian)
    for (int i = 0; i < 32; ++i) {
        buffer[4 + i] = header.prevBlockHash[31 - i];
    }

    // Merkle root (32 bytes, little endian)
    for (int i = 0; i < 32; ++i) {
        buffer[36 + i] = header.merkleRoot[31 - i];
    }

    // Timestamp (4 bytes, little endian)
    buffer[68] = header.timestamp & 0xFF;
    buffer[69] = (header.timestamp >> 8) & 0xFF;
    buffer[70] = (header.timestamp >> 16) & 0xFF;
    buffer[71] = (header.timestamp >> 24) & 0xFF;

    // Bits (4 bytes, little endian)
    buffer[72] = header.bits & 0xFF;
    buffer[73] = (header.bits >> 8) & 0xFF;
    buffer[74] = (header.bits >> 16) & 0xFF;
    buffer[75] = (header.bits >> 24) & 0xFF;

    // Nonce (4 bytes, little endian)
    buffer[76] = header.nonce & 0xFF;
    buffer[77] = (header.nonce >> 8) & 0xFF;
    buffer[78] = (header.nonce >> 16) & 0xFF;
    buffer[79] = (header.nonce >> 24) & 0xFF;

    return buffer;
}

std::array<uint32_t, 8> calculateMidstateArray(const std::vector<uint8_t>& headerPrefix) {
    if (headerPrefix.size() < 64)
        throw std::runtime_error("Header prefix must be at least 64 bytes");

    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    SHA256_Update(&ctx, headerPrefix.data(), 64);

    // Return the midstate (internal state after first block)
    return {ctx.state[0], ctx.state[1], ctx.state[2], ctx.state[3],
            ctx.state[4], ctx.state[5], ctx.state[6], ctx.state[7]};
}
