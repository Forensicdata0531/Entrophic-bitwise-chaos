// block.cpp

#include "block.hpp"
#include "hash_utils.hpp"
#include "sha256_wrapper.hpp"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <sstream>

// Helper to convert a hash to hex
std::string hashToHex(const std::array<uint8_t, 32>& hash) {
    std::ostringstream ss;
    for (auto byte : hash) {
        ss << std::hex << std::setfill('0') << std::setw(2) << (int)byte;
    }
    return ss.str();
}

// Helper to reverse a hash (to match Bitcoin's little-endian display)
std::array<uint8_t, 32> reverseHash(const std::array<uint8_t, 32>& hash) {
    std::array<uint8_t, 32> reversed;
    std::reverse_copy(hash.begin(), hash.end(), reversed.begin());
    return reversed;
}

// Converts hex string to byte array (assumes even-length hex string)
std::vector<uint8_t> hexToBytes(const std::string& hex) {
    if (hex.length() % 2 != 0) {
        throw std::invalid_argument("Hex string must have even length");
    }

    std::vector<uint8_t> bytes;
    bytes.reserve(hex.length() / 2);
    for (size_t i = 0; i < hex.length(); i += 2) {
        std::string byteStr = hex.substr(i, 2);
        uint8_t byte = static_cast<uint8_t>(std::stoul(byteStr, nullptr, 16));
        bytes.push_back(byte);
    }
    return bytes;
}

// Converts a JSON block template into a BlockHeader struct
BlockHeader parseBlockTemplate(const json& blockTemplate) {
    BlockHeader header;
    header.version = blockTemplate["version"].get<uint32_t>();

    std::string prevHashStr = blockTemplate["previousblockhash"];
    std::string merkleStr = blockTemplate["merkleroot"];

    // Convert hex strings to byte arrays (reversed for little-endian)
    std::vector<uint8_t> prevHashVec = hexToBytes(prevHashStr);
    std::reverse(prevHashVec.begin(), prevHashVec.end());
    std::copy(prevHashVec.begin(), prevHashVec.end(), header.prevBlockHash.begin());

    std::vector<uint8_t> merkleVec = hexToBytes(merkleStr);
    std::reverse(merkleVec.begin(), merkleVec.end());
    std::copy(merkleVec.begin(), merkleVec.end(), header.merkleRoot.begin());

    header.timestamp = blockTemplate["curtime"].get<uint32_t>();
    header.bits = std::stoul(blockTemplate["bits"].get<std::string>(), nullptr, 16);
    header.nonce = 0;

    return header;
}

// Double SHA-256 hash of the block header
std::array<uint8_t, 32> hashBlockHeader(const BlockHeader& header) {
    std::vector<uint8_t> bytes = header.toBytes(); // Must be defined in BlockHeader
    return doubleSHA256(bytes.data(), bytes.size());
}
