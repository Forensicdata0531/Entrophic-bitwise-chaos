#ifndef SHA256_WRAPPER_H
#define SHA256_WRAPPER_H

#include <cstdint>
#include <cstddef>
#include <vector>

// SHA-256: Hashes input into 32-byte output
void sha256(const uint8_t* data, size_t len, uint8_t* outHash);

// Double SHA-256: Returns a new 32-byte vector
std::vector<uint8_t> doubleSHA256(const uint8_t* data, size_t len);

#endif // SHA256_WRAPPER_H
