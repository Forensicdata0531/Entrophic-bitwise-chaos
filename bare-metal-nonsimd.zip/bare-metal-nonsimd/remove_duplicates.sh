#!/bin/bash

# === SETTINGS ===
KEEP_FILE="./shared.cpp"
FUNCS=("doubleSHA256" "serializeHeader80")
EXT="bak"

# === BACKUP & REMOVE ===
for FUNC in "${FUNCS[@]}"; do
    echo "🔍 Cleaning duplicates for: $FUNC"
    
    # Find all .cpp/.mm/.hpp files with definitions of the function (not just declarations)
    FILES=$(grep -rlE "std::vector<uint8_t>\s+${FUNC}\s*\(" . | grep -E '\.(cpp|mm|hpp)$')
    
    for FILE in $FILES; do
        if [[ "$FILE" != "$KEEP_FILE" ]]; then
            echo "🧹 Removing $FUNC from $FILE"
            
            # Backup the original
            cp "$FILE" "$FILE.$EXT"

            # Remove the function definition (naively assumes it’s not nested or templated)
            perl -0777 -i -pe "s|std::vector<uint8_t>\s+${FUNC}\s*\([^)]*\)\s*\{[^{}]*\{[^}]*\}[^}]*\}|// Removed duplicate of $FUNC|gs" "$FILE"
        else
            echo "✅ Keeping definition in $KEEP_FILE"
        fi
    done
done

echo "✅ Cleanup complete. Original files saved with .$EXT extension."
