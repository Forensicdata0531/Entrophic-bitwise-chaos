#include "block.hpp"
#include "shared.hpp"
#include <iostream>
#include <vector>
#include <cstring>
#include <atomic>
#include <algorithm>

// Forward declaration of metalMineBlock from metal_miner.mm
bool metalMineBlock(
    const BlockHeader& header,
    const std::vector<uint8_t>& target,
    uint32_t initialNonceBase,
    uint32_t& validNonce,
    std::vector<uint8_t>& validHash,
    uint64_t maxThreads = 233017);

// Mining statistics
struct MiningStats {
    std::atomic<uint64_t> hashes{0};
};

MiningStats stats;

// Calculate target from bits field (Bitcoin difficulty)
std::vector<uint8_t> calculateTargetFromBits(uint32_t bits) {
    uint32_t exponent = bits >> 24;
    uint32_t mantissa = bits & 0xFFFFFF;
    std::vector<uint8_t> target(32, 0x00);

    int shift = exponent - 3;
    if (shift >= 0 && shift + 3 <= 32) {
        target[shift] = (mantissa >> 16) & 0xFF;
        target[shift + 1] = (mantissa >> 8) & 0xFF;
        target[shift + 2] = mantissa & 0xFF;
    }
    return target;
}

// Simple CPU miner fallback (for demonstration)
bool cpuMineBlock(
    const BlockHeader& header,
    const std::vector<uint8_t>& target,
    uint32_t nonceStart,
    uint32_t nonceEnd,
    uint32_t& validNonce,
    std::vector<uint8_t>& validHash)
{
    BlockHeader blockHeader = header;

    for (uint32_t nonce = nonceStart; nonce < nonceEnd; ++nonce) {
        blockHeader.nonce = nonce;
        auto headerBytes = serializeHeader80(blockHeader); // from shared.cpp
        auto hash = doubleSHA256(headerBytes.data(), headerBytes.size());

        stats.hashes++;

        if (std::lexicographical_compare(hash.begin(), hash.end(), target.begin(), target.end())) {
            validNonce = nonce;
            validHash = hash;
            std::cerr << "[DEBUG] CPU found valid nonce: " << nonce << "\n";
            return true;
        }

        if (stats.hashes % 1000000 == 0) {
            std::cerr << "[DEBUG] Hashes computed: " << stats.hashes << std::endl;
        }
    }
    return false;
}

int main() {
    std::cerr << "[DEBUG] Miner started\n";

    BlockHeader blockHeader{};
    blockHeader.version = 0x20000000;
    std::memset(blockHeader.prevBlockHash.data(), 0x00, 32);
    std::memset(blockHeader.merkleRoot.data(), 0x11, 32);
    blockHeader.timestamp = 1717430400;
    blockHeader.bits = 0x1d00ffff; // Bitcoin difficulty bits
    blockHeader.nonce = 0;

    std::vector<uint8_t> target = calculateTargetFromBits(blockHeader.bits);

    uint32_t validNonce = 0;
    std::vector<uint8_t> validHash;

    std::cerr << "[DEBUG] Starting Metal mining...\n";

    bool found = metalMineBlock(blockHeader, target, 0, validNonce, validHash, 1024);

    if (found) {
        std::cerr << "[INFO] Metal mining succeeded with nonce: " << validNonce << "\n";
    } else {
        std::cerr << "[INFO] Metal mining failed, falling back to CPU mining...\n";
        found = cpuMineBlock(blockHeader, target, 0, 1000000, validNonce, validHash);

        if (found) {
            std::cerr << "[INFO] CPU mining succeeded with nonce: " << validNonce << "\n";
        } else {
            std::cerr << "[INFO] CPU mining also failed in tested range\n";
        }
    }

    return 0;
}
