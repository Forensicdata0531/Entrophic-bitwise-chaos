#include "midstate_utils.hpp"

// The block header is 80 bytes total
// Midstate is calculated on the first 64 bytes (without nonce)
// Tail is the last 16 bytes (nonce + padding)

void computeMidstate(const BlockHeader& header, std::array<uint32_t, 8>& midstate, std::vector<uint8_t>& tail) {
    std::vector<uint8_t> fullHeader = header.toBytes();
    if (fullHeader.size() != 80) throw std::runtime_error("Block header must be 80 bytes");

    // First 64 bytes for midstate calculation
    std::vector<uint8_t> prefix(fullHeader.begin(), fullHeader.begin() + 64);

    Midstate ms = calculateMidstate(prefix);

    midstate = ms.h;

    // Tail = bytes 64 to 79 (last 16 bytes)
    tail.assign(fullHeader.begin() + 64, fullHeader.end());
}
